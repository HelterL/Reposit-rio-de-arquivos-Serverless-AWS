$('#login-cadastro').button(function(){
    
return true;
});