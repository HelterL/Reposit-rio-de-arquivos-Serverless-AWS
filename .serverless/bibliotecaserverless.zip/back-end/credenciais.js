    var BUCKET_NAME =  "teste321lev3456";
    var API_MYSQL = "https://68k0b2xc8c.execute-api.us-east-1.amazonaws.com/dev/readdb";
    var API_LIST = "https://68k0b2xc8c.execute-api.us-east-1.amazonaws.com/dev/listar";
    var API_SMS = "https://68k0b2xc8c.execute-api.us-east-1.amazonaws.com/dev/enviarsms";