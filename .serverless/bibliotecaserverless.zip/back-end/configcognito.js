window._config = {
    cognito: {
        userPoolId: "us-east-1_adBTnzC5A", // UserPoolId
        region: 'us-east-1', // Região
		clientId: "76qmkla4lg3ck3tm6h9498giml"
    },
};

