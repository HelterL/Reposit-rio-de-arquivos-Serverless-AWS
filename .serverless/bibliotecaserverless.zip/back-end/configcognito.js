window._config = {
    cognito: {
        userPoolId: "UserPoolId", // UserPoolId
        region: 'us-east-1', // Região
		clientId: "UserPoolClientId"
    },
};

