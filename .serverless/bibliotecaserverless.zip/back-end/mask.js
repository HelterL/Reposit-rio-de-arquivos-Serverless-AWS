$(document).ready(function () { 
    $('#phone').mask('(00) 00000-0000');
});