    var BUCKET_NAME =  "Nome do bucket";
    var API_MYSQL = "cole a api api_mysql";
    var API_LIST = "cole a api_mysql";
